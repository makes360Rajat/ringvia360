# Changelog

## 1.9.8

1.9.6, numbered to install over the 1.9.7 build made elsewhere (1.8.2-based:
it deleted events on upgrade, lacked the installer fix, Clear Data and the
deleted-phone actions, and its own gates crashed). Matching app release: the
first heartbeat goes at once after pairing and on every start, so the health
report shows within seconds, and a one-minute check while the app is on screen
unpairs a phone revoked or deleted in the CRM within a minute.
One migration, 198; schema revision 20.

## 1.9.6

- Deleting a device now deletes everything it sent: calls, messages,
  recordings on this server, AI insights and contacts.
- Fixed: a phone paired again as a new device after its old device was deleted
  showed only its newest calls (48 of 1000+). Its history was refused as a
  duplicate of the deleted device's rows. History held by a deleted or revoked
  device now moves to the new device when the phone sends it again.
- Entries left by devices deleted before 1.9.6: Devices shows how many, with
  Delete them; a person's device page offers Move them to this device.
- One migration, 196; schema revision 19 (no schema change).

## 1.9.5

- Fixed: a revoked device could not be paired again. Pair Again issued a code,
  but the phone was always told "invalid code", so a new device had to be
  created. The same device now pairs again with that new code, on the same
  phone or another, keeping its name, person, settings and history. Codes
  issued before the revoke stay void, and the old token stays refused.
- One migration, 195; schema revision 19 (no schema change).

## 1.9.4

- Devices > a phone > Clear Data (administrators): remove what the phone sent,
  everything or one kind at a time (calls, WhatsApp calls, SMS, WhatsApp
  messages, phone contacts), for all time or only entries older than 30, 90,
  180 or 365 days. Counts show beside each choice; a confirmation is asked
  first; the activity log records what was cleared. Recordings on this server
  and AI insights go with their calls.
- One migration, 194; schema revision 19 (no schema change).

## 1.9.3

- A revoked phone is now told `device_revoked` on every call, as the API
  promises; before, revoking cleared its token and it only ever saw
  `invalid_token`. A deleted phone still gets `invalid_token`. Either way the
  app (from its matching release) unpairs and shows the pairing screen.
- One migration, 193; schema revision 19 (no schema change).

## 1.9.2

- Pairing is by the 6-digit code only: the CRM no longer shows a QR code to
  scan, on the pairing panel or the device page, and no longer sends one in
  its replies. Buttons and notes use a code icon instead of a QR icon.
- One migration, 192; schema revision 19 (no schema change).

## 1.9.1

1.8.9, numbered to install over the 1.9.0 build made elsewhere, which brought
back deleting events on upgrade, time-window merging, invented calls, the
installer that fails with "Table already exists", a literal "Un Saved" as the
contact name, and dropped the WhatsApp Messages tab, Calls by Contact,
Details, contacts and check. Upgrading from 1.9.0 deletes nothing.
One migration, 191; schema revision 19.

## 1.8.9

- Fixed: uploading 1.8.8 and running Upgrade Database in the same request
  stopped with "Table 'tblmks_sales_track_contacts' already exists". The
  installer now runs once per request, checks tables with a fresh query
  instead of CodeIgniter's cached table list, and creates every table with
  CREATE TABLE IF NOT EXISTS.
- An automatic update that cannot finish is logged and retried on the next
  request instead of stopping the CRM.
- One migration, 189; schema revision 18. Gates 140.

## 1.8.8

Built on 1.8.5; installs over the 1.8.6 and 1.8.7 builds made elsewhere,
whose 1.8.2-based sync code it replaces.

- Calls > By Contact: each number once, the most recent first, like a phone's
  call history, with its calls (in, out, missed), talk time and recordings.
  Open a number to see every call with it, newest first: direction, time,
  length, staff, phone and SIM, outcome and note, the recording to play, and
  Details. Period, person and name-or-number search; 25 numbers a page.
- WhatsApp calls and WhatsApp messages stay on their own tabs.
- Every list opens newest first.
- Call Lists, Best Pitches, Follow-ups and Missed Calls no longer show as tabs;
  their pages still answer at their addresses.
- Calmer spacing: even gaps between the tab bar, header, filters, tiles and
  tables; tiles wrap evenly; the tab bar scrolls on narrow screens.
- API `events` (GET): this phone's own events, newest first, filtered by kind
  (or `whatsapp` for both WhatsApp kinds) and `since`, paged. POST is sync.
- Settings and pairing codes are written straight to the options table and
  read back from it, so Perfex's caches can never lose a pairing code (kept
  from the 1.8.7 build).
- One migration, 188; schema revision 17. Gates 139, end-to-end checks 70.

## 1.8.5

Built on 1.8.3; installs over 1.8.4 (whose 1.8.2-based sync code is replaced).

- WhatsApp messages: a new kind, `whatsapp_message`, with its own switch
  (Tracking > WhatsApp Messages, on by default) and the SMS text privacy rule.
  A WhatsApp or WhatsApp Business chat sent as `notification` is stored as a
  WhatsApp message; other apps' notifications are still refused
  (`kind_not_tracked`). A WhatsApp Messages tab lists them with their text.
- Phone contacts: new `contacts` endpoint (up to 2000 a request, gzip welcome)
  and switch (Tracking > Phone Contacts). Names saved on the phone fill calls
  and messages that arrived without one, past and future. A phone's contacts go
  when the phone is deleted, and with a purge.
- History imported at pairing: up to 365 days (default 30).
- Calls tiles add up: Calls = Connected + Not Connected, which shows its missed
  and not-answered split. The WhatsApp tab is now WhatsApp Calls.
- A lead's Perfex status (which may itself be called "Customer") is shown as an
  outlined "Status" chip, apart from the Lead and Customer labels.
- Details: an eye button on every entry shows everything stored for it.
- Lists refresh by themselves every 30 seconds while on screen.
- Not carried over from 1.8.4: its duplicate cleaner on upgrade, time-window
  merging, calls created for recordings, and its extra migration files.
- Schema revision 14. Gates 138, end-to-end checks 68.

## 1.8.3

Exact sync for the phone apps. Built on 1.8.0; supersedes the 1.8.1 and 1.8.2
builds.

- The same uid sent again with fuller details (a longer duration, a direction
  where there was none, an unanswered call that turned out answered, a number,
  name or SIM) completes the stored call in place; the sync reply lists it
  under the new `updated`. A recording still owed is asked for again.
- Live calls: events may carry `provisional` (seen by the call-state listener)
  and `replaces` (the uid this event supersedes). The call log's entry then
  completes the same row instead of adding a second one, keeps everything a
  person added, and remembers the earlier uid, so a recording uploaded under
  either uid finds its call.
- New `check` endpoint: up to 500 of the phone's uids, answered with which
  arrived, under which uid, with their recording state.
- Recording uploads may carry `sha256`; a damaged file is refused (422
  `checksum_mismatch`) instead of stored. Recordings removed by retention
  answer `already` so the phone deletes its copy.
- JSON bodies may be gzipped (`Content-Encoding: gzip`, inflated to 16 MB at
  most). config and pair carry `sync`: batch size, history limit, features.
- Notifications and WhatsApp messages are refused with `kind_not_tracked`, so
  the app knows to stop sending them.
- Not carried over from 1.8.1 and 1.8.2: merging calls or messages to the same
  number within one or two minutes (it merged missed calls with their
  callbacks and deleted SMS), the duplicate cleaner on upgrade (it deleted real
  events), creating calls from recordings, matching recordings across phones,
  tracking notifications and WhatsApp messages, history back to 2000, and the
  extra migration files. Upgrading from 1.8.2 deletes nothing; events 1.8.2
  deleted cannot be brought back by any upgrade, only from a backup.
- Schema revision 13 (10 to 12 were used by 1.8.2): events gain `alt_uid` and
  `provisional`. One migration file, 183.
- Gates 137, end-to-end checks 64.

## 1.8.0

Phase 9, the last CRM phase.

- Call Lists tab: managers and team leads build a list from lead filters
  (status, source, owner, not contacted for N days, created between, open
  only), share it among reps evenly or by owner, and follow progress. Reps see
  their own leads with Call buttons and Skip. Whether a lead was called,
  reached or given an outcome is read from the calls themselves. Lists need no
  new table: headers and lead assignments are kept in options.
- Do Not Call (Settings > Privacy): no Call buttons for those numbers, never
  on a call list, click-to-call refuses them, managers add numbers from a
  list, and phones receive them as salted hashes to warn before dialling.
- Caller popup (Settings > Caller Popup): phones fetch a directory of leads
  (all or their own), customers and contacts (by the customer names rule, all
  or none), colleagues and extra entries, with status, owner, last call and
  outcome, last note and next follow-up; a version in the heartbeat says when
  to fetch again, and a lookup answers for one number.
- Wallboard: today's totals, leaderboard and latest calls for a sales-floor
  screen, from the Dashboard for managers and team leads, or through a secret
  link (off by default, renewable). Rep names and figures only.
- AI: the default model is now gemini-3.1-flash-lite, prices to match, and
  Choose From My Key's Models lists the models the key may use. Existing
  installs keep their chosen model.
- API: lists, directory and lookup endpoints; config carries do_not_call,
  popup and call_lists.
- Fixed: demo data loaded before the working day began dated today's calls in
  the future.
- Gates 132, end-to-end checks 54.

## 1.7.0

Phase 8.

- AI insights with Google Gemini, over raw cURL with a JSON schema: the call's
  transcript (Hindi, Punjabi, English or a mix), summary, sentiment, how hot
  the lead is, objections, next steps, a score card from your own criteria
  (the score is worked out from the marks, not taken from the model), flags
  for competitors, discount or price promises, abusive language and watched
  words, and a suggested outcome.
- Settings > AI (Gemini): key (encrypted), model, automatic rule (CRM numbers,
  every call, or on request only), length limits, monthly budget with prices
  per million tokens, score card, competitors, watched words, alerts,
  suggestions, whether reps see their own insights, weekly coaching. Test The
  Key checks the key and model.
- An AI column on Calls and Recordings: score, temperature and flags, opening
  the Insights window, or Analyse for managers and team leads.
- Flags alert the people chosen under Alerts. A suggested outcome is applied
  only when a person clicks Use This Outcome.
- Weekly coaching notes per rep to their team lead, written from the week's
  figures, on the weekly report's day and time.
- An AI Insights report: analysed calls, average score, hot, warm and cold,
  sentiment, flagged calls and, for managers, cost.
- Only the call's recording, direction, length, the rep's name and the
  module's own lists are sent; never lead or customer details.
- A third table, tblmks_sales_track_ai, holds transcripts and full analyses so
  the events table stays light for every list read; uninstall with purge drops
  it too.
- Gates 126, end-to-end checks 47.

## 1.6.0

Phase 7.

- Settings > Recording Storage: keep recordings on this server or on Google
  Drive, delete server recordings after set days (0 keeps them), who may
  download, the listening log, Best Pitch nominations and categories.
- Google Drive: one Workspace account connected through OAuth (drive.file
  scope: Sales Track sees only what it created), client secret and refresh
  token stored encrypted. The cron run uploads new recordings with resumable
  uploads into Sales Track / year / month / rep, verifies size and MD5, and
  deletes the server copy after the days set. Playback streams from Drive
  through the CRM with seeking, under the same permission checks.
- Best Pitches tab: a library open to everyone who uses Sales Track, filtered
  by category, with notes and clickable moments. Managers (new capability
  Manage Best Pitches) add calls or approve the nominations reps send with the
  star on Calls and Recordings. Best Pitches are never deleted.
- Every play and download goes to Perfex's activity log (once per person and
  recording every ten minutes); a Recording Access report lists them for
  managers. The Recordings report counts recordings on Drive.
- tooling/fake_google.php: a local stand-in for Google's OAuth, Drive and FCM
  endpoints, so Drive storage and push are tested end to end; only a test
  install's own config can point the module at it.
- Gates 120, end-to-end checks 45.

## 1.5.0

Phase 6.

- Reports tab with eleven reports: Team Summary, Daily Activity, Missed Calls
  And Callbacks, Call Duration, Outcomes, Speed To Lead, Lead Engagement,
  Conversion, Recordings, SMS and Phone Health. Presets or a custom period up
  to a year, team and person filters, totals rows, notes on how each is
  counted, all scoped like the rest of the module.
- Export any report to CSV (UTF-8 for Excel, formula-safe) or to an Excel
  workbook (numbers stay numbers, durations in minutes); print view.
- Conversion analytics: leads each rep spoke to, how many were converted in
  Perfex, Converted outcomes, and paid invoices from those customers for
  people allowed to see customers and invoices.
- Scheduled email reports through Perfex's own email settings: daily at a set
  time, weekly on a set day, monthly on the 1st; to managers, team leads (their
  team) and each rep (their own day); empty ones skipped. Preview and Send It
  To Me Now in Settings > Email Reports.
- Gates 115, end-to-end checks 43.

## 1.4.0

Phase 5.

- Automatic leads: off until switched on; rules for incoming, outgoing or both,
  minimum length, WhatsApp calls, working hours only, and calls imported at
  pairing. Created through Perfex's Leads_model with the status, source and
  assignment already set for leads from calls.
- Last Contact on the lead follows its latest connected call, also when calls
  link to a lead later.
- A Calls tab on the lead window and the customer profile: totals, every call,
  WhatsApp call and SMS the viewer may see, outcomes, recordings playable in
  place, and Call buttons.
- Click-to-call: Call buttons on Calls and WhatsApp rows, Missed Calls,
  Follow-ups and the Calls tabs make the user's own company phone dial.
  Delivered at once through Firebase Cloud Messaging (service account key in
  Settings, stored encrypted, never shown again) and on the next heartbeat
  otherwise; a dial expires after two minutes.
- Phones register their Firebase token; the device page shows it and can send
  a test push.
- Lead activity and notifications are stored as language keys with their
  values, as core does.
- Fixed: looking up a name between a query's where() and update() leaked into
  the half-built query when a lead was created from the API.
- Gates 110, end-to-end checks 39.

## 1.3.0

Phase 4.

- After-call outcomes: an editable outcome list in Settings (colour, asks for a
  follow-up, sets a lead status, active), with Converted fixed. The phone sends
  answers to the new `outcome` endpoint; the CRM sets and changes them from an
  Outcome column on Calls and WhatsApp, with an outcome filter.
- Follow-ups are native Perfex reminders on the lead or customer, emailed if
  set; a Follow-ups page lists them as Due, Upcoming and Done.
- Create Lead from the phone, by the status, source and assignment set in
  Settings, through Perfex's own Leads_model.
- Converted: managers are told and convert with Perfex's own Convert To
  Customer (Ready To Convert on the dashboard), or the lead moves to a status.
- Missed Calls page: the callback queue, counted in working hours, cleared by
  any connected call with the number, escalated on Perfex's cron to team leads
  or managers, by notification and email.
- Never Attended and Never Received filters on Calls.
- Device alerts: tampering reported by the phone, lost permissions, silent
  phones; shown on the device page and sent as set in Settings > Alerts.
- Customer matching can be switched off; who sees customer names is a setting;
  a customer number also shows the lead behind it.
- Lead activity: outcomes, status changes and reminders logged under the real
  actor's name.
- Demo data includes outcomes, follow-ups and the queue.
- Gates 103, end-to-end checks 37.

## 1.2.0

Phase 3.

- The Dashboard becomes analytics: Today, Yesterday, 7 Days, 30 Days, This
  Month and Last Month; team and person filters; eight KPI tiles, each against
  the equal period before; calls by day (or by hour for one day) split
  connected and not; how calls ended; best calling times by weekday and hour
  with the best hour called out; targets; a leaderboard ranked by calls,
  connected calls or talk time; latest activity and phone status.
- Reps see My Dashboard (themselves), team leads their department, managers
  everybody. New capability: View Team Activity (Perfex departments are teams).
- Targets section in Settings: working days, daily calls, connected calls and
  talk time, and per-person overrides.
- Calls between staff are left out of analytics (switchable).
- Charts are drawn as SVG on the server.
- Gates 95, end-to-end checks 31.

## 1.1.0

Phase 2.

- One sidebar item, Sales Track, opening a new Dashboard (the day's numbers,
  phone health, latest activity); a tab bar on every module page.
- A dedicated Settings page drawn from `config/settings_schema.php`, with a
  section menu; Setup > Settings keeps a link to it. New settings: connected
  call threshold, one phone per staff member, revoke on deactivation, minimum
  app version, store links, App Lock and its PIN.
- Devices v2: add a device (name, description, staff member, SIM number, asset
  tag) and get its 6-digit code and QR; the device page shows a live code
  again, regenerates it to swap handsets, pauses, resumes, revokes and
  deletes, queues commands, and shows health, activity and sync history.
- API: pairing binds to the device record; config carries `paused`, `app`,
  `app_lock`, `commands`, `update_required` and accepts `acks`; sync and
  recording answer 426 to outdated apps.
- Lead status (in Perfex's own colour), Converted, Lost and Junk, and inactive
  customers shown next to every call.
- Notifications removed.
- Deactivating or deleting a staff member revokes their phones.
- docs/ROADMAP.md, docs/SETTINGS.md (generated) and docs/APP_DEVELOPER.md.
- Gates grow to 84, the end-to-end suite to 29 checks.

## 1.0.0

First release (phase 1).

- Two tables, `tblmks_sales_track_devices` and `tblmks_sales_track_events`.
- Phone API: ping, pair, config, sync, recording. Token per device, CSRF exempt
  through the module's own config file, idempotent sync.
- Pairing with a QR code or a six digit code, single use, throttled.
- Calls, Recordings, WhatsApp Calls, SMS and Notifications lists with filters,
  search and KPI tiles that always describe the rows shown.
- A floating recording player with seek and speed, streaming with range
  support through a permission checked endpoint.
- Devices page with phone health, SIM choice, revoke and delete.
- Numbers matched to customers, leads and staff on their last digits, and
  re-matched when a lead, contact or customer is saved.
- Settings tab with General, Tracking, Privacy, Recordings and Devices And API
  sections, sent to the phones.
- Five capabilities: View Own Activity, View All Activity, Play Recordings,
  Manage All Devices, Delete Activity.
- Demo data loaded through the real ingest path and removable in one click.
- Release gates (`tooling/gates.php`), an end to end suite (`tooling/e2e.php`)
  and a phone simulator (`tooling/phone.php`).
