<?php

defined('BASEPATH') or exit('No direct script access allowed');

/**
 * MKS Sales Track - calls grouped by number, like a phone's call history:
 * each number once, the latest call first, its counts and talk time, and
 * every call with its recording and details one click away.
 *
 * @var array  $groups
 * @var array  $filters range, staff, q
 * @var array  $ranges
 * @var array  $staff_options
 * @var int    $page
 * @var int    $pages
 * @var int    $total
 * @var string $nav
 */

init_head();

$mks_url = function (array $change) use ($filters, $page) {
    $params = array_merge(['range' => $filters['range'], 'staff' => $filters['staff'], 'q' => $filters['q'], 'page' => $page], $change);

    return admin_url(MKS_SALES_TRACK_MODULE_NAME . '/calls_by_contact?' . http_build_query(array_filter($params, function ($value) {
        return $value !== '' && $value !== 0 && $value !== null && $value !== 1;
    })));
};
?>
<div id="wrapper">
    <div class="content">
        <div class="mks-sales-track mks-sales-track-groups-page">

            <?php $this->load->view(MKS_SALES_TRACK_MODULE_NAME . '/partials/nav', ['nav' => $nav]); ?>

            <div class="mks-sales-track-head">
                <div class="mks-sales-track-head-main">
                    <span class="mks-sales-track-head-icon"><i class="fa-solid fa-phone" aria-hidden="true"></i></span>
                    <div>
                        <h4 class="mks-sales-track-title"><?= e(_l('mks_st_page_calls')); ?></h4>
                        <p class="mks-sales-track-sub"><?= e(_l('mks_st_groups_sub')); ?></p>
                    </div>
                </div>
                <div class="mks-sales-track-head-actions">
                    <div class="mks-sales-track-segment" role="group" aria-label="<?= e(_l('mks_st_view_as')); ?>">
                        <a href="<?= admin_url(MKS_SALES_TRACK_MODULE_NAME . '/calls'); ?>" class="mks-sales-track-segment-btn"><?= e(_l('mks_st_view_all_calls')); ?></a>
                        <a href="<?= e($mks_url(['page' => 1])); ?>" class="mks-sales-track-segment-btn is-active"><?= e(_l('mks_st_view_by_contact')); ?></a>
                    </div>
                </div>
            </div>

            <form method="get" action="<?= admin_url(MKS_SALES_TRACK_MODULE_NAME . '/calls_by_contact'); ?>" class="mks-sales-track-card mks-sales-track-filters">
                <input type="hidden" name="range" value="<?= e($filters['range']); ?>">
                <div class="mks-sales-track-filters-row">
                    <div class="mks-sales-track-segment" role="group" aria-label="<?= e(_l('mks_st_filter_range')); ?>">
                        <?php foreach ($ranges as $mks_value => $mks_label) { ?>
                        <a href="<?= e($mks_url(['range' => $mks_value, 'page' => 1])); ?>" class="mks-sales-track-segment-btn<?= $filters['range'] === $mks_value ? ' is-active' : ''; ?>"><?= e(_l($mks_label)); ?></a>
                        <?php } ?>
                    </div>
                    <?php if ($staff_options) { ?>
                    <label class="mks-sales-track-select">
                        <i class="fa-solid fa-user" aria-hidden="true"></i>
                        <select name="staff" class="mks-sales-track-autosubmit" aria-label="<?= e(_l('mks_st_col_staff')); ?>">
                            <option value=""><?= e(_l('mks_st_all_staff')); ?></option>
                            <?php foreach ($staff_options as $mks_id => $mks_name) { ?>
                            <option value="<?= (int) $mks_id; ?>"<?= (int) $filters['staff'] === (int) $mks_id ? ' selected' : ''; ?>><?= e($mks_name); ?></option>
                            <?php } ?>
                        </select>
                    </label>
                    <?php } ?>
                    <span class="mks-sales-track-group-search">
                        <input type="search" name="q" class="form-control" value="<?= e($filters['q']); ?>" placeholder="<?= e(_l('mks_st_groups_search')); ?>" aria-label="<?= e(_l('mks_st_groups_search')); ?>">
                        <button type="submit" class="btn btn-default btn-sm"><i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i></button>
                    </span>
                </div>
            </form>

            <?php if (!$groups) { ?>
            <div class="mks-sales-track-card mks-sales-track-empty">
                <span class="mks-sales-track-empty-icon"><i class="fa-solid fa-phone" aria-hidden="true"></i></span>
                <h5><?= e(_l('mks_st_groups_empty')); ?></h5>
            </div>
            <?php } else { ?>
            <p class="mks-sales-track-groups-count"><?= e(_l('mks_st_groups_count', mks_st_number_label($total))); ?></p>
            <div class="mks-sales-track-groups" id="mks-sales-track-groups">
                <?php foreach ($groups as $mks_group) {
                    $mks_last = $mks_group['last'];
                    $mks_dir  = mks_st_direction_meta($mks_last); ?>
                <div class="mks-sales-track-card mks-sales-track-group">
                    <div class="mks-sales-track-group-head" data-url="<?= e(admin_url(MKS_SALES_TRACK_MODULE_NAME . '/call_group?' . http_build_query(['key' => $mks_group['number_key'], 'range' => $filters['range'], 'staff' => $filters['staff']]))); ?>">
                        <span class="mks-sales-track-group-dir mks-sales-track-tone-<?= e($mks_dir['tone']); ?>" title="<?= e($mks_dir['label']); ?>"><i class="fa-solid <?= e($mks_dir['icon']); ?>" aria-hidden="true"></i></span>
                        <div class="mks-sales-track-group-who">
                            <?= mks_st_render_contact($mks_last); ?>
                            <span class="mks-sales-track-group-last"><?= e(_l('mks_st_groups_last', [$mks_dir['label'], _dt($mks_last['occurred_at']), trim((string) $mks_last['staff_first'] . ' ' . (string) $mks_last['staff_last'])])); ?></span>
                        </div>
                        <div class="mks-sales-track-group-stats">
                            <span class="mks-sales-track-group-stat"><strong><?= (int) $mks_group['calls']; ?></strong> <?= e(_l((int) $mks_group['calls'] === 1 ? 'mks_st_groups_call' : 'mks_st_groups_calls')); ?></span>
                            <span class="mks-sales-track-group-split" title="<?= e(_l('mks_st_groups_split_hint')); ?>">
                                <span class="mks-sales-track-tone-green"><i class="fa-solid fa-arrow-down" aria-hidden="true"></i><?= (int) $mks_group['incoming']; ?></span>
                                <span class="mks-sales-track-tone-blue"><i class="fa-solid fa-arrow-up" aria-hidden="true"></i><?= (int) $mks_group['outgoing']; ?></span>
                                <span class="mks-sales-track-tone-red"><i class="fa-solid fa-phone-slash" aria-hidden="true"></i><?= (int) $mks_group['missed']; ?></span>
                            </span>
                            <span class="mks-sales-track-group-stat"><i class="fa-solid fa-clock" aria-hidden="true"></i> <?= e(mks_st_duration_label($mks_group['talk'])); ?></span>
                            <?php if ((int) $mks_group['recordings'] > 0) { ?>
                            <span class="mks-sales-track-group-stat"><i class="fa-solid fa-microphone" aria-hidden="true"></i> <?= (int) $mks_group['recordings']; ?></span>
                            <?php } ?>
                        </div>
                        <button type="button" class="mks-sales-track-icon-btn mks-sales-track-group-toggle" aria-expanded="false" aria-label="<?= e(_l('mks_st_groups_open')); ?>" title="<?= e(_l('mks_st_groups_open')); ?>">
                            <i class="fa-solid fa-chevron-down" aria-hidden="true"></i>
                        </button>
                    </div>
                    <div class="mks-sales-track-group-body" hidden></div>
                </div>
                <?php } ?>
            </div>

            <?php if ($pages > 1) { ?>
            <div class="mks-sales-track-pager">
                <?php if ($page > 1) { ?><a class="btn btn-default btn-sm" href="<?= e($mks_url(['page' => $page - 1])); ?>"><i class="fa-solid fa-chevron-left" aria-hidden="true"></i></a><?php } ?>
                <span><?= e(_l('mks_st_page_of', [(string) $page, (string) $pages])); ?></span>
                <?php if ($page < $pages) { ?><a class="btn btn-default btn-sm" href="<?= e($mks_url(['page' => $page + 1])); ?>"><i class="fa-solid fa-chevron-right" aria-hidden="true"></i></a><?php } ?>
            </div>
            <?php } ?>
            <?php } ?>

            <div class="modal fade mks-sales-track-modal" id="mks-sales-track-event-modal" tabindex="-1" role="dialog" aria-labelledby="mks-sales-track-event-title">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="<?= e(_l('mks_st_close')); ?>"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title" id="mks-sales-track-event-title"><i class="fa-solid fa-eye" aria-hidden="true"></i> <?= e(_l('mks_st_details')); ?></h4>
                        </div>
                        <div class="modal-body" id="mks-sales-track-event-body"></div>
                    </div>
                </div>
            </div>

            <?php $this->load->view(MKS_SALES_TRACK_MODULE_NAME . '/partials/player'); ?>
        </div>
    </div>
</div>
<?php init_tail(); ?>
</body>

</html>
