<?php

defined('BASEPATH') or exit('No direct script access allowed');

/**
 * MKS Sales Track - every call with one number, newest first, as a phone's
 * call details screen shows them, each with its recording and details.
 *
 * @var array $calls   detail rows
 * @var array $devices id => label
 * @var array $context row context for the renderers
 * @var bool  $more    there are more calls than shown
 */
$mks_outcomes = mks_st_outcomes(false);
?>
<div class="mks-sales-track-timeline">
    <?php foreach ($calls as $event) {
        $dir     = mks_st_direction_meta($event);
        $staff   = trim((string) $event['staff_first'] . ' ' . (string) $event['staff_last']);
        $phone   = isset($devices[(int) $event['device_id']]) ? $devices[(int) $event['device_id']] : '';
        $outcome = $event['outcome'] !== null && isset($mks_outcomes[$event['outcome']]) ? $mks_outcomes[$event['outcome']] : null; ?>
    <div class="mks-sales-track-timeline-item">
        <span class="mks-sales-track-group-dir mks-sales-track-tone-<?= e($dir['tone']); ?>"><i class="fa-solid <?= e($dir['icon']); ?>" aria-hidden="true"></i></span>
        <div class="mks-sales-track-timeline-main">
            <div><strong><?= e($dir['label']); ?></strong> <span class="mks-sales-track-muted"><?= e(_dt($event['occurred_at'])); ?></span></div>
            <div class="mks-sales-track-muted mks-sales-track-small">
                <?= e((int) $event['duration'] > 0 ? mks_st_duration_label($event['duration']) : _l('mks_st_detail_no_talk')); ?>
                <?php if ($staff !== '') { ?> &middot; <?= e($staff); ?><?php } ?>
                <?php if ($phone !== '') { ?> &middot; <?= e($phone); ?><?= $event['sim_slot'] !== null ? ', SIM ' . (int) $event['sim_slot'] : ''; ?><?php } ?>
            </div>
            <?php if ($outcome) { ?>
            <div class="mks-sales-track-timeline-outcome">
                <span class="mks-sales-track-pill mks-sales-track-tone-<?= e($outcome['tone']); ?>"><?= e($outcome['label']); ?></span>
                <?php if ((string) $event['outcome_note'] !== '') { ?><span><?= e($event['outcome_note']); ?></span><?php } ?>
            </div>
            <?php } ?>
        </div>
        <div class="mks-sales-track-timeline-rec"><?= mks_st_render_recording($event, $context); ?></div>
        <button type="button" class="mks-sales-track-icon-btn mks-sales-track-event-view" data-id="<?= (int) $event['id']; ?>" title="<?= e(_l('mks_st_details')); ?>" aria-label="<?= e(_l('mks_st_details')); ?>"><i class="fa-solid fa-eye" aria-hidden="true"></i></button>
    </div>
    <?php } ?>
    <?php if ($more) { ?>
    <p class="mks-sales-track-muted mks-sales-track-small"><?= e(_l('mks_st_groups_more')); ?></p>
    <?php } ?>
</div>
