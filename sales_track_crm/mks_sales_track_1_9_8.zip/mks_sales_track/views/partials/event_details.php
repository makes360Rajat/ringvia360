<?php

defined('BASEPATH') or exit('No direct script access allowed');

/**
 * MKS Sales Track - everything stored for one entry, exactly as it arrived
 * from the phone and as the CRM matched it.
 *
 * @var array $event
 * @var array $device
 */
$mks_v     = function ($key) use ($event) {
    return isset($event[$key]) && $event[$key] !== null && $event[$key] !== '' ? $event[$key] : null;
};
$mks_kinds = [
    'call'             => _l('mks_st_kind_call'),
    'whatsapp_call'    => _l('mks_st_kind_whatsapp_call'),
    'sms'              => _l('mks_st_kind_sms'),
    'whatsapp_message' => _l('mks_st_kind_whatsapp_message'),
];
$mks_dir   = mks_st_direction_meta($event);
$mks_rel   = '';

if ($event['rel_type'] === 'lead' && $mks_v('lead_name')) {
    $mks_rel = _l('mks_st_rel_lead') . ': ' . $event['lead_name'];
} elseif ($event['rel_type'] === 'customer' && $mks_v('client_company') && mks_st_customer_visible()) {
    $mks_rel = _l('mks_st_rel_customer') . ': ' . $event['client_company'];
} elseif ($event['rel_type'] === 'staff' && $mks_v('rel_staff_first')) {
    $mks_rel = _l('mks_st_rel_staff') . ': ' . trim($event['rel_staff_first'] . ' ' . $event['rel_staff_last']);
}

$mks_rows = [
    _l('mks_st_detail_type')      => isset($mks_kinds[$event['kind']]) ? $mks_kinds[$event['kind']] : $event['kind'],
    _l('mks_st_detail_direction') => $mks_dir['label'],
    _l('mks_st_detail_time')      => _dt($event['occurred_at']),
    _l('mks_st_detail_number')    => $mks_v('number') !== null ? mks_st_format_number($event['number']) : $mks_v('number_raw'),
    _l('mks_st_detail_sent_as')   => $mks_v('number_raw'),
    _l('mks_st_detail_phone_name') => $mks_v('contact_name'),
    _l('mks_st_detail_crm')       => $mks_rel !== '' ? $mks_rel : _l('mks_st_detail_not_in_crm'),
    _l('mks_st_col_staff')        => trim((string) $mks_v('staff_first') . ' ' . (string) $mks_v('staff_last')),
    _l('mks_st_detail_phone')     => isset($device['label']) ? $device['label'] . ($mks_v('sim_slot') !== null ? ', SIM ' . (int) $event['sim_slot'] : '') : null,
];

if (in_array($event['kind'], ['call', 'whatsapp_call'], true)) {
    $mks_rows[_l('mks_st_col_duration')] = (int) $event['duration'] > 0 ? mks_st_duration_label($event['duration']) : _l('mks_st_detail_no_talk');
}

if ($event['kind'] === 'whatsapp_call') {
    $mks_rows[_l('mks_st_detail_media')] = $mks_v('media') === 'video' ? _l('mks_st_media_video') : _l('mks_st_media_voice');
}

if ($event['kind'] === 'call') {
    $mks_rows[_l('mks_st_col_recording')] = $event['recording_status'] === 'stored'
        ? _l('mks_st_recording_stored') . ($mks_v('recording_size') !== null ? ', ' . mks_st_bytes_label($event['recording_size']) : '') . ($mks_v('drive_file_id') !== null ? ', ' . _l('mks_st_on_drive') : '')
        : ($event['recording_status'] === 'pending' ? _l('mks_st_recording_pending') : ($event['recording_status'] === 'expired' ? _l('mks_st_recording_expired') : '-'));
}

if (in_array($event['kind'], ['sms', 'whatsapp_message'], true)) {
    $mks_rows[_l('mks_st_detail_text')] = $mks_v('body') !== null ? $event['body'] : _l('mks_st_detail_text_hidden');
}

if ($mks_v('app_package') !== null) {
    $mks_rows[_l('mks_st_detail_app')] = $event['app_package'] === 'com.whatsapp.w4b' ? 'WhatsApp Business' : ($event['app_package'] === 'com.whatsapp' ? 'WhatsApp' : $event['app_package']);
}

if ($mks_v('title') !== null) {
    $mks_rows[_l('mks_st_detail_title')] = $event['title'];
}

if ($mks_v('outcome') !== null) {
    $mks_outcomes = mks_st_outcomes(false);
    $mks_rows[_l('mks_st_col_outcome')] = (isset($mks_outcomes[$event['outcome']]) ? $mks_outcomes[$event['outcome']]['label'] : $event['outcome'])
        . ($mks_v('outcome_note') !== null ? ': ' . $event['outcome_note'] : '');
}

if ($mks_v('follow_up_at') !== null) {
    $mks_rows[_l('mks_st_detail_follow_up')] = _dt($event['follow_up_at']);
}

$mks_rows[_l('mks_st_detail_uid')] = $event['uid'] . ($mks_v('alt_uid') !== null ? ' (' . _l('mks_st_detail_was', $event['alt_uid']) . ')' : '');
$mks_rows[_l('mks_st_detail_received')] = $mks_v('received_at') !== null ? _dt($event['received_at']) : null;
?>
<div class="mks-sales-track mks-sales-track-event-details">
    <dl>
        <?php foreach ($mks_rows as $mks_label => $mks_value) {
            if ($mks_value === null || $mks_value === '') {
                continue;
            } ?>
        <dt><?= e($mks_label); ?></dt>
        <dd><?= nl2br(e((string) $mks_value)); ?></dd>
        <?php } ?>
    </dl>
</div>
