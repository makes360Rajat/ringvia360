<?php

defined('BASEPATH') or exit('No direct script access allowed');

/**
 * MKS Sales Track - the floating recording player, shared by the lists and
 * the grouped calls view.
 */
?>
            <div class="mks-sales-track-player" id="mks-sales-track-player" aria-hidden="true">
                <button type="button" class="mks-sales-track-player-main" id="mks-sales-track-player-toggle"
                    aria-label="<?= e(_l('mks_st_play')); ?>">
                    <i class="fa-solid fa-play" aria-hidden="true"></i>
                </button>
                <div class="mks-sales-track-player-body">
                    <div class="mks-sales-track-player-meta">
                        <span class="mks-sales-track-player-title" id="mks-sales-track-player-title"></span>
                        <span class="mks-sales-track-player-sub" id="mks-sales-track-player-sub"></span>
                    </div>
                    <div class="mks-sales-track-player-track">
                        <span class="mks-sales-track-player-time" id="mks-sales-track-player-current">0:00</span>
                        <input type="range" class="mks-sales-track-player-seek" id="mks-sales-track-player-seek"
                            min="0" max="1000" step="1" value="0" aria-label="<?= e(_l('mks_st_seek')); ?>">
                        <span class="mks-sales-track-player-time" id="mks-sales-track-player-total">0:00</span>
                    </div>
                </div>
                <button type="button" class="mks-sales-track-player-pill" id="mks-sales-track-player-speed"
                    title="<?= e(_l('mks_st_speed')); ?>">1x</button>
                <a class="mks-sales-track-player-icon" id="mks-sales-track-player-download" href="#"
                    title="<?= e(_l('mks_st_download')); ?>" aria-label="<?= e(_l('mks_st_download')); ?>">
                    <i class="fa-solid fa-download" aria-hidden="true"></i>
                </a>
                <button type="button" class="mks-sales-track-player-icon" id="mks-sales-track-player-close"
                    aria-label="<?= e(_l('mks_st_close')); ?>">
                    <i class="fa-solid fa-xmark" aria-hidden="true"></i>
                </button>
                <audio id="mks-sales-track-audio" preload="none"></audio>
            </div>
